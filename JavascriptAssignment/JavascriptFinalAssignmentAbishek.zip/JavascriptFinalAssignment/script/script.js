


function Submit()
{
 var uname=document.getElementById("username");
var regx=/^([a-zA-z]{2,30})$/;
var emailid=document.getElementById("emailid");
var regx1=/^([a-z0-9\.-]+)@([a-z0-9-]+).([a-z]{2,8})(.[a-z]{2,8})?$/;
var currentaddress=document.getElementById("address");
var city=document.getElementById("city");
var permanentaddress=document.getElementById("choice");
var permanentcity=document.getElementById("permanentcity");
var permanentaddresss=document.getElementById("addresss");
var fathersname=document.getElementById("fathersname")
var dob=document.getElementById("dob");
var regx2=/^(0[1-9]|1\d|2\d|3[01])\/(0[1-9]|1[0-2])\/(19|20)\d{2}$/;
var mobilenumber=document.getElementById("mobilenumber");
var regx3=/^[6-9][0-9]{9}$/;
var regx4=/^[1-9][0-9]{5}$/;
var address2=document.getElementById("address2");
var pincode=document.getElementById("pincode");
var address3=document.getElementById("address3");
var zipcode=document.getElementById("zipcode");
 
    if(uname.value.trim()=="")
    {
        uname.style.border="solid 3px red";
        console.log("name cannot be blank");
        document.getElementById("uservalue").innerHTML="Name cannot be blank";
        
    }
    else if(!(uname.value.trim()=="")) 
    {
        if(regx.test(uname.value))
        {
            uname.style.border="solid 3px black";
        document.getElementById("uservalue").innerHTML="valid";
            
            
        }
        else
        {
        
            uname.style.border="solid 3px red";
            document.getElementById("uservalue").innerHTML="Name cannot contain numbers";
            console.log("name cannot contain numbers: ");
        }
    
    }
   
    
    if(emailid.value.trim()=="")
    {
        emailid.style.border="solid 3px red";
        console.log("emailid cannot be blank");
        document.getElementById("emailvalue").innerHTML="emailid cannot be blank";
    }
    else if(!(emailid.value.trim()==""))
    {
        
        
        if(regx1.test(emailid.value))
        {
        emailid.style.border="solid 3px black";
        document.getElementById("emailvalue").innerHTML=null;
        
        }
    else
        {
        
        emailid.style.border="solid 3px red";
        document.getElementById("emailvalue").innerHTML="email id is not in correct format";
        console.log("email id is not in correct format ");
        
        }
    }
    
    if(currentaddress.value.trim()=="")
    {
        currentaddress.style.border="solid 3px red";
        console.log("Address field cannot be blank");
        document.getElementById("currentaddresss").innerHTML="Address field cannot be blank";
        
    }
    else
    {
        currentaddress.style.border="solid 3px black";
        document.getElementById("currentaddresss").innerHTML="";
    }
    if(city.value.trim()=="")
    {
        city.style.border="solid 3px red";
        console.log("city field cannot be blank");
        document.getElementById("cityvalue").innerHTML="city field cannot be blank";
        
    }
    else{
        city.style.border="solid 3px black";
        document.getElementById("cityvalue").innerHTML="";
    }
    if(permanentcity.value.trim()=="" )
    {
        permanentcity.style.border="solid 3px red";
        console.log("city field cannot be blank");
        document.getElementById("permanentcity").innerHTML="permanent city field cannot be blank";
    }
    else{
        permanentcity.style.border="solid 3px black";
        document.getElementById("permanentcity").innerHTML="";

    }
    if(permanentaddresss.value.trim()=="")
    {
        permanentaddresss.style.border="solid 3px red";
        console.log("city field cannot be blank");
        document.getElementById("permanentaddressvalue").innerHTML="permanent address field cannot be blank";
    }
    else{
        permanentaddresss.style.border="solid 3px black";
        document.getElementById("permanentaddressvalue").innerHTML="";
    }
    if(permanentcity.value.trim()=="")
    {
        permanentcity.style.border="solid 3px red";
        console.log("city field cannot be blank");
        document.getElementById("permanentcityvalue").innerHTML="permanent city field cannot be blank";
    }
    else{
        permanentcity.style.border="solid 3px black";
        document.getElementById("permanentcityvalue").innerHTML="";
    }
    if(fathersname.value.trim()=="")
    {
        fathersname.style.border="solid 3px red";
        console.log("name cannot be blank");
        document.getElementById("fathersvalue").innerHTML="Name cannot be blank";
        
    }
    else if(!(fathersname.value.trim()==""))
    {
        if(regx.test(fathersname.value))
        {
            fathersname.style.border="solid 3px black";
        document.getElementById("fathersvalue").innerHTML="valid";
            
            
        }
        else
        {
        
            fathersname.style.border="solid 3px red";
            document.getElementById("fathersvalue").innerHTML="Name cannot contain numbers";
            console.log("name cannot contain numbers: ");
        }
    
    }
    if(dob.value.trim()=="")
    {
        dob.style.border="solid 3px red";
        console.log("date of birth cannot be blank");
        document.getElementById("dobvalue").innerHTML="date of birth cannot be blank";
        
    }
    else if(!(dob.value.trim()=="")) 
    {
        if(regx2.test(dob.value))
        {
            dob.style.border="solid 3px black";
        document.getElementById("dobvalue").innerHTML="valid";
            
            
        }
        else
        {
        
            uname.style.border="solid 3px red";
            document.getElementById("dobvalue").innerHTML=" date of birth is not in correct format of DD/MM/YYYY";
            console.log("date of birth is not in correct format of DD/MM/YYYY ");
        }
    
    }
    if(mobilenumber.value.trim()=="")
    {
        mobilenumber.style.border="solid 3px red";
        console.log("name cannot be blank");
        document.getElementById("mobilenumbervalue").innerHTML="mobile number cannot be blank";
        
    }
    else if(!(mobilenumber.value.trim()=="")) 
    {
        if(regx3.test(mobilenumber.value))
        {
            mobilenumber.style.border="solid 3px black";
        document.getElementById("mobilenumbervalue").innerHTML="valid";
            
            
        }
        else
        {
        
            mobilenumber.style.border="solid 3px red";
            document.getElementById("mobilenumbervalue").innerHTML="mobile number not in proper format";
            console.log("mobile number not in proper format");
        }
    
    }
    if(address2.value.trim()=="")
    {
        address2.style.border="solid 3px red";
        console.log("Address2 field cannot be blank");
        document.getElementById("address2value").innerHTML="Address2 field cannot be blank";
        
    }
    else
    {
        address2.style.border="solid 3px black";
        document.getElementById("address2value").innerHTML="";
    }
    if(pincode.value.trim()=="")
    {
        pincode.style.border="solid 3px red";
        console.log("pincode cannot be blank");
        document.getElementById("pincodevalue").innerHTML="pincode cannot be blank";
        
    }
    else if(!(pincode.value.trim()=="")) 
    {
        if(regx4.test(pincode.value))
        {
            pincode.style.border="solid 3px black";
        document.getElementById("pincodevalue").innerHTML="valid";
            
            
        }
        else
        {
        
            pincode.style.border="solid 3px red";
            document.getElementById("pincodevalue").innerHTML="pincode is not in regular format";
            console.log("pincode not in format ");
        }
    
    }
    if(address3.value.trim()=="")
    {
        address3.style.border="solid 3px red";
        console.log("Address3 field cannot be blank");
        document.getElementById("address3value").innerHTML="Address3 field cannot be blank";
        
    }
    else
    {
        address3.style.border="solid 3px black";
        document.getElementById("address3value").innerHTML="";
    }
    if(zipcode.value.trim()=="")
    {
        zipcode.style.border="solid 3px red";
        console.log("zipcode cannot be blank");
        document.getElementById("zipcodevalue").innerHTML="zipcode cannot be blank";
        
    }
    else if(!(zipcode.value.trim()=="")) 
    {
        if(regx4.test(zipcode.value))
        {
        zipcode.style.border="solid 3px black";
        document.getElementById("zipcode").innerHTML="valid";
            
            
        }
        else
        {
        
            zipcode.style.border="solid 3px red";
            document.getElementById("zipcode").innerHTML="zipcode is not in regular format";
            console.log("zipcode not in format ");
        }
    
    }

}

function printMsg()
{
    var permanentaddress=document.getElementById("choice");
if(permanentaddress.checked==true)
{
    var val=document.getElementById("city").value;
    document.getElementById("permanentcity").value=val;
    var val1=document.getElementById("address").value;
    document.getElementById("addresss").value=val1;
    var val2=document.getElementById("district").value;
    document.getElementById("permanentdistrict").value=val2;
}
else if((permanentaddress.checked==false))
{
    
        document.getElementById("permanentcity").value=" ";
        document.getElementById("addresss").value=" ";
        document.getElementById("permanentdistrict").value="Tamil Nadu";
        
    
}

}